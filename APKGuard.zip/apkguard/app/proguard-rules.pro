-keep class com.apkguard.** { *; }
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
