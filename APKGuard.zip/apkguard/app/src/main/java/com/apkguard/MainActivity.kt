// lang: Kotlin, file: MainActivity.kt, target: Android 8.0+ / Android 15
// Bosh ekran: faollashtirish → APK tanlash → AnalysisActivity ga o'tish

package com.apkguard

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.apkguard.databinding.ActivityMainBinding
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var isActivated = false

    // ─── Storage ruxsat so'rash ──────────────────────────────────────────

    private val storagePermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val granted = results.values.any { it }
        if (granted) {
            openApkPicker()
        } else {
            Toast.makeText(this, "Fayl o'qish uchun ruxsat kerak", Toast.LENGTH_LONG).show()
        }
    }

    // ─── APK tanlovchi ───────────────────────────────────────────────────

    private val apkPickerLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { handleApkUri(it) }
    }

    // ─── onCreate ────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Agar ilova APK fayli bilan ochilgan bo'lsa
        handleIncomingIntent(intent)

        binding.btnActivate.setOnClickListener {
            activateApp()
        }

        binding.btnSelectApk.setOnClickListener {
            checkStorageAndPickApk()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingIntent(intent)
    }

    // ─── Incoming APK intent (boshqa ilovadan yuborilgan APK) ───────────

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_VIEW) {
            val uri = intent.data
            if (uri != null) {
                if (!isActivated) activateApp()
                handleApkUri(uri)
            }
        }
    }

    // ─── Faollashtirish ──────────────────────────────────────────────────

    private fun activateApp() {
        isActivated = true
        binding.idleLayout.visibility = android.view.View.GONE
        binding.activeLayout.visibility = android.view.View.VISIBLE
        binding.statusDot.text = "● FAOL"
        binding.statusDot.setTextColor(ContextCompat.getColor(this, R.color.safe_green))
    }

    // ─── Storage ruxsat + picker ─────────────────────────────────────────

    private fun checkStorageAndPickApk() {
        when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU -> {
                // Android 13+ — READ_MEDIA_IMAGES va shu kabi ruxsatlar media uchun
                // APK uchun ACTION_GET_CONTENT to'g'ridan ishlaydi, ruxsat shart emas
                openApkPicker()
            }
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.M -> {
                val perm = Manifest.permission.READ_EXTERNAL_STORAGE
                if (ContextCompat.checkSelfPermission(this, perm) == PackageManager.PERMISSION_GRANTED) {
                    openApkPicker()
                } else {
                    storagePermLauncher.launch(arrayOf(perm))
                }
            }
            else -> openApkPicker()
        }
    }

    private fun openApkPicker() {
        apkPickerLauncher.launch("application/vnd.android.package-archive")
    }

    // ─── APK URI → vaqtinchalik fayl → tahlil ───────────────────────────

    private fun handleApkUri(uri: Uri) {
        try {
            val fileName = getFileNameFromUri(uri) ?: "unknown.apk"
            val tempFile = File(cacheDir, "apkguard_temp_${System.currentTimeMillis()}.apk")

            // URI dan faylni cache ga ko'chirish
            contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(tempFile).use { output ->
                    input.copyTo(output)
                }
            } ?: run {
                Toast.makeText(this, "Fayl o'qilmadi", Toast.LENGTH_SHORT).show()
                return
            }

            // AnalysisActivity ga o'tish
            val intent = Intent(this, AnalysisActivity::class.java).apply {
                putExtra(AnalysisActivity.EXTRA_APK_PATH, tempFile.absolutePath)
                putExtra(AnalysisActivity.EXTRA_APK_DISPLAY_NAME, fileName)
            }
            startActivity(intent)

        } catch (e: Exception) {
            Toast.makeText(this, "Xato: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    // ─── URI dan fayl nomini olish ───────────────────────────────────────

    private fun getFileNameFromUri(uri: Uri): String? {
        return try {
            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                cursor.moveToFirst()
                if (nameIndex >= 0) cursor.getString(nameIndex) else null
            } ?: uri.lastPathSegment
        } catch (_: Exception) {
            uri.lastPathSegment
        }
    }
}
