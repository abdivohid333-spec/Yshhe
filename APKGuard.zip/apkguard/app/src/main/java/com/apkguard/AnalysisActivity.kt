// lang: Kotlin, file: AnalysisActivity.kt, target: Android 8.0+ / Android 15
// APK tahlil qiladi, hisobot ko'rsatadi, O'RNATISH / O'RNATMASLIK tugmasi

package com.apkguard

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.apkguard.databinding.ActivityAnalysisBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class AnalysisActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_APK_PATH = "apk_path"
        const val EXTRA_APK_DISPLAY_NAME = "apk_display_name"
    }

    private lateinit var binding: ActivityAnalysisBinding
    private var apkFile: File? = null
    private var analysisResult: ApkAnalysisResult? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAnalysisBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val apkPath = intent.getStringExtra(EXTRA_APK_PATH)
        val displayName = intent.getStringExtra(EXTRA_APK_DISPLAY_NAME) ?: "app.apk"

        binding.btnBack.setOnClickListener { finish() }

        binding.btnInstall.setOnClickListener { launchInstaller() }
        binding.btnCancel.setOnClickListener {
            Toast.makeText(this, "O'rnatish bekor qilindi", Toast.LENGTH_SHORT).show()
            finish()
        }

        if (apkPath == null) {
            Toast.makeText(this, "Fayl yo'li topilmadi", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        apkFile = File(apkPath)
        if (!apkFile!!.exists()) {
            Toast.makeText(this, "Fayl mavjud emas", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        startAnalysis(apkFile!!, displayName)
    }

    // ─── Tahlilni boshlaish ───────────────────────────────────────────────

    private fun startAnalysis(file: File, displayName: String) {
        binding.progressOverlay.visibility = View.VISIBLE
        binding.resultScroll.visibility = View.GONE
        binding.actionBar.visibility = View.GONE

        val analyzer = ApkAnalyzer(this)

        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                analyzer.analyze(file, onStep = { step ->
                    lifecycleScope.launch(Dispatchers.Main) {
                        binding.progressStep.text = step
                    }
                })
            }

            analysisResult = result
            withContext(Dispatchers.Main) {
                showResult(result, displayName)
            }
        }
    }

    // ─── Hisobotni ko'rsatish ─────────────────────────────────────────────

    private fun showResult(result: ApkAnalysisResult, displayName: String) {
        binding.progressOverlay.visibility = View.GONE
        binding.resultScroll.visibility = View.VISIBLE
        binding.actionBar.visibility = View.VISIBLE

        // APK info bar
        binding.apkName.text = displayName
        val sizeStr = formatSize(result.fileSizeBytes)
        binding.apkMeta.text = "Paket: ${result.packageName} · v${result.versionName}"
        binding.apkSize.text = sizeStr

        // Verdict banner
        when (result.verdict) {
            RiskLevel.SAFE -> {
                binding.verdictIcon.text = "✅"
                binding.verdictLabel.text = "XAVFSIZ"
                binding.verdictLabel.setTextColor(color(R.color.safe_green))
                binding.verdictBanner.setBackgroundResource(R.drawable.bg_card)
                binding.btnInstall.backgroundTintList =
                    ContextCompat.getColorStateList(this, R.color.accent_cyan)
            }
            RiskLevel.SUSPICIOUS -> {
                binding.verdictIcon.text = "⚠️"
                binding.verdictLabel.text = "SHUBHALI"
                binding.verdictLabel.setTextColor(color(R.color.warn_amber))
                binding.verdictBanner.setBackgroundResource(R.drawable.bg_warn_card)
                binding.btnInstall.backgroundTintList =
                    ContextCompat.getColorStateList(this, R.color.warn_amber)
            }
            RiskLevel.DANGEROUS -> {
                binding.verdictIcon.text = "🚨"
                binding.verdictLabel.text = "XAVFLI"
                binding.verdictLabel.setTextColor(color(R.color.danger_red))
                binding.verdictBanner.setBackgroundResource(R.drawable.bg_danger_card)
                binding.btnInstall.backgroundTintList =
                    ContextCompat.getColorStateList(this, R.color.danger_red)
                binding.btnInstall.text = "BARIBIR O'RNATISH"
            }
        }
        binding.verdictDesc.text = result.verdictSummary

        // Purpose
        binding.purposeText.text = result.appPurpose

        // Capabilities
        binding.capabilitiesContainer.removeAllViews()
        result.capabilities.forEach { cap ->
            addBulletRow(binding.capabilitiesContainer, cap, color(R.color.text_secondary), "•")
        }

        // Permissions
        binding.permCount.text = "${result.permissions.size} ta"
        binding.permissionsContainer.removeAllViews()
        if (result.permissions.isEmpty()) {
            addBulletRow(binding.permissionsContainer, "Hech qanday ruxsat so'ralmagan", color(R.color.text_secondary), "✓")
        } else {
            result.permissions.sortedByDescending {
                when (it.riskLevel) {
                    RiskLevel.DANGEROUS -> 2
                    RiskLevel.SUSPICIOUS -> 1
                    RiskLevel.SAFE -> 0
                }
            }.forEach { perm ->
                addPermissionRow(perm)
            }
        }

        // Network
        binding.networkContainer.removeAllViews()
        if (result.networkEndpoints.isEmpty()) {
            addBulletRow(
                binding.networkContainer,
                "Hech qanday tarmoq manzili aniqlanmadi",
                color(R.color.safe_green), "✓"
            )
        } else {
            result.networkEndpoints.take(20).forEach { ep ->
                addNetworkRow(ep)
            }
            if (result.networkEndpoints.size > 20) {
                addBulletRow(
                    binding.networkContainer,
                    "… va yana ${result.networkEndpoints.size - 20} ta manzil",
                    color(R.color.text_secondary), "+"
                )
            }
        }

        // Danger signals
        if (result.dangerSignals.isNotEmpty()) {
            binding.cardDanger.visibility = View.VISIBLE
            binding.dangerContainer.removeAllViews()
            result.dangerSignals.forEach { signal ->
                addDangerRow(signal)
            }
        } else {
            binding.cardDanger.visibility = View.GONE
        }
    }

    // ─── Helper view yaratuvchilar ───────────────────────────────────────

    private fun addBulletRow(container: LinearLayout, text: String, textColor: Int, bullet: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, 0, 0, dpToPx(6)) }
            gravity = Gravity.TOP
        }
        val bulletView = TextView(this).apply {
            text = bullet
            setTextColor(textColor)
            textSize = 12f
            layoutParams = LinearLayout.LayoutParams(dpToPx(18), LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        val textView = TextView(this).apply {
            this.text = text
            setTextColor(textColor)
            textSize = 12f
            setLineSpacing(0f, 1.35f)
            layoutParams = LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
            )
        }
        row.addView(bulletView)
        row.addView(textView)
        container.addView(row)
    }

    private fun addPermissionRow(perm: PermissionInfo) {
        val bgRes = when (perm.riskLevel) {
            RiskLevel.DANGEROUS -> R.drawable.bg_perm_danger
            else -> R.drawable.bg_perm_tag
        }
        val iconChar = when (perm.riskLevel) {
            RiskLevel.DANGEROUS -> "🔴"
            RiskLevel.SUSPICIOUS -> "🟡"
            RiskLevel.SAFE -> "🟢"
        }
        val nameColor = when (perm.riskLevel) {
            RiskLevel.DANGEROUS -> color(R.color.danger_red)
            RiskLevel.SUSPICIOUS -> color(R.color.warn_amber)
            RiskLevel.SAFE -> color(R.color.text_primary)
        }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(bgRes)
            val pad = dpToPx(10)
            setPadding(pad, pad, pad, pad)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, 0, 0, dpToPx(6)) }
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val iconView = TextView(this).apply {
            text = iconChar
            textSize = 12f
            layoutParams = LinearLayout.LayoutParams(dpToPx(24), LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        val nameView = TextView(this).apply {
            text = perm.shortName
            setTextColor(nameColor)
            textSize = 13f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        header.addView(iconView)
        header.addView(nameView)

        val descView = TextView(this).apply {
            text = perm.description
            setTextColor(color(R.color.text_secondary))
            textSize = 11f
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(dpToPx(24), dpToPx(2), 0, 0) }
            setLineSpacing(0f, 1.3f)
        }

        card.addView(header)
        card.addView(descView)
        binding.permissionsContainer.addView(card)
    }

    private fun addNetworkRow(ep: NetworkEndpoint) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.TOP
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, 0, 0, dpToPx(6)) }
        }
        val typeIcon = when (ep.type) {
            "IP" -> "🖥"
            "Domain" -> "🌐"
            else -> "🔗"
        }
        val typeView = TextView(this).apply {
            text = "$typeIcon "
            textSize = 12f
            layoutParams = LinearLayout.LayoutParams(dpToPx(26), LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        val urlView = TextView(this).apply {
            text = ep.url
            setTextColor(color(R.color.text_secondary))
            textSize = 11f
            typeface = android.graphics.Typeface.MONOSPACE
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        row.addView(typeView)
        row.addView(urlView)
        binding.networkContainer.addView(row)
    }

    private fun addDangerRow(signal: DangerSignal) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, 0, 0, dpToPx(8)) }
        }
        val titleView = TextView(this).apply {
            text = "⚠ ${signal.title}"
            setTextColor(color(R.color.danger_red))
            textSize = 12f
        }
        val detailView = TextView(this).apply {
            text = signal.detail
            setTextColor(color(R.color.text_secondary))
            textSize = 11f
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, dpToPx(2), 0, 0) }
        }
        val sourceView = TextView(this).apply {
            text = "Manba: ${signal.source}"
            setTextColor(color(R.color.text_secondary))
            textSize = 10f
            typeface = android.graphics.Typeface.MONOSPACE
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, dpToPx(2), 0, 0) }
        }
        card.addView(titleView)
        card.addView(detailView)
        card.addView(sourceView)
        binding.dangerContainer.addView(card)
    }

    // ─── O'rnatish ───────────────────────────────────────────────────────

    private fun launchInstaller() {
        val file = apkFile ?: return
        try {
            val uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            } else {
                Uri.fromFile(file)
            }

            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
            }

            if (intent.resolveActivity(packageManager) != null) {
                startActivity(intent)
            } else {
                Toast.makeText(this, "O'rnatuvchi topilmadi", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "O'rnatish xatosi: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    // ─── Yordamchi funksiyalar ───────────────────────────────────────────

    private fun formatSize(bytes: Long): String {
        return when {
            bytes >= 1024 * 1024 -> "%.1f MB".format(bytes / (1024.0 * 1024.0))
            bytes >= 1024 -> "%.0f KB".format(bytes / 1024.0)
            else -> "$bytes B"
        }
    }

    private fun dpToPx(dp: Int): Int =
        (dp * resources.displayMetrics.density).toInt()

    private fun color(resId: Int): Int =
        ContextCompat.getColor(this, resId)
}
