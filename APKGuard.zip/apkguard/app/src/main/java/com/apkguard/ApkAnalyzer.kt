// lang: Kotlin, file: ApkAnalyzer.kt, target: Android 8.0+, Android 15 mos
// APK faylni ZIP sifatida ochib, AndroidManifest.xml va boshqa ma'lumotlarni tahlil qiladi
// Haqiqiy tahlil: binary manifest decode + string scan + permission classification

package com.apkguard

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import java.io.File
import java.io.InputStream
import java.util.zip.ZipFile

// ─── Ma'lumot tuzilmalari ───────────────────────────────────────────────────

enum class RiskLevel { SAFE, SUSPICIOUS, DANGEROUS }

data class PermissionInfo(
    val name: String,
    val shortName: String,
    val description: String,
    val riskLevel: RiskLevel
)

data class NetworkEndpoint(
    val url: String,
    val type: String // URL, IP, Domain
)

data class DangerSignal(
    val title: String,
    val detail: String,
    val source: String
)

data class ApkAnalysisResult(
    val apkName: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val minSdkVersion: Int,
    val targetSdkVersion: Int,
    val fileSizeBytes: Long,
    val appPurpose: String,
    val capabilities: List<String>,
    val permissions: List<PermissionInfo>,
    val networkEndpoints: List<NetworkEndpoint>,
    val dangerSignals: List<DangerSignal>,
    val verdict: RiskLevel,
    val verdictSummary: String
)

// ─── Tahlil mexanizmi ───────────────────────────────────────────────────────

class ApkAnalyzer(private val context: Context) {

    companion object {

        // Xavfli ruxsatlar ro'yxati + tavsif
        private val PERMISSION_DB = mapOf(
            "android.permission.READ_CONTACTS" to Triple(
                "Kontaktlarni o'qish", "Telefon daftaridagi barcha kontaktlarni ko'radi", RiskLevel.SUSPICIOUS
            ),
            "android.permission.WRITE_CONTACTS" to Triple(
                "Kontaktlarni o'zgartirish", "Kontaktlarni qo'shadi, o'chiradi yoki tahrirlaydi", RiskLevel.SUSPICIOUS
            ),
            "android.permission.READ_CALL_LOG" to Triple(
                "Qo'ng'iroqlar tarixini o'qish", "Barcha qo'ng'iroqlar tarixini ko'radi", RiskLevel.DANGEROUS
            ),
            "android.permission.PROCESS_OUTGOING_CALLS" to Triple(
                "Chiquvchi qo'ng'iroqlarni boshqarish", "Qo'ng'iroqlarni to'xtatishi yoki yo'naltirishi mumkin", RiskLevel.DANGEROUS
            ),
            "android.permission.READ_SMS" to Triple(
                "SMS o'qish", "Barcha SMS xabarlarni o'qiydi", RiskLevel.DANGEROUS
            ),
            "android.permission.SEND_SMS" to Triple(
                "SMS yuborish", "Siz bilmasdan SMS yuborishi mumkin (pul sarflanishi mumkin)", RiskLevel.DANGEROUS
            ),
            "android.permission.RECEIVE_SMS" to Triple(
                "SMS qabul qilish", "Keladigan SMS larni ushlab qolishi mumkin", RiskLevel.DANGEROUS
            ),
            "android.permission.RECORD_AUDIO" to Triple(
                "Mikrofon", "Istalgan vaqtda audio yozib olishi mumkin", RiskLevel.DANGEROUS
            ),
            "android.permission.CAMERA" to Triple(
                "Kamera", "Kamerani ishlatishi mumkin", RiskLevel.SUSPICIOUS
            ),
            "android.permission.ACCESS_FINE_LOCATION" to Triple(
                "Aniq joylashuv (GPS)", "GPS orqali aniq manzilingizni biladi", RiskLevel.DANGEROUS
            ),
            "android.permission.ACCESS_COARSE_LOCATION" to Triple(
                "Taxminiy joylashuv", "Wi-Fi/mobil tarmoq orqali taxminiy joylashuvni biladi", RiskLevel.SUSPICIOUS
            ),
            "android.permission.ACCESS_BACKGROUND_LOCATION" to Triple(
                "Fon rejimida joylashuv", "Ilova yopiq bo'lganida ham joylashuvni kuzatadi", RiskLevel.DANGEROUS
            ),
            "android.permission.READ_EXTERNAL_STORAGE" to Triple(
                "Xotirani o'qish", "SD kart va ichki xotiradagi fayllarni o'qiydi", RiskLevel.SUSPICIOUS
            ),
            "android.permission.WRITE_EXTERNAL_STORAGE" to Triple(
                "Xotiraga yozish", "Fayllar yaratadi, o'chiradi yoki o'zgartiradi", RiskLevel.SUSPICIOUS
            ),
            "android.permission.INTERNET" to Triple(
                "Internet", "Internet ulanishdan foydalanadi", RiskLevel.SAFE
            ),
            "android.permission.RECEIVE_BOOT_COMPLETED" to Triple(
                "Qurilma yonganida ishga tushish", "Telefon yoqilganda avtomatik boshlanadi", RiskLevel.SUSPICIOUS
            ),
            "android.permission.FOREGROUND_SERVICE" to Triple(
                "Fon xizmati", "Doim fonda ishlaydi", RiskLevel.SUSPICIOUS
            ),
            "android.permission.REQUEST_INSTALL_PACKAGES" to Triple(
                "APK o'rnatish", "Boshqa ilovalarni avtomatik o'rnatishi mumkin", RiskLevel.DANGEROUS
            ),
            "android.permission.SYSTEM_ALERT_WINDOW" to Triple(
                "Boshqa ilovalar ustida ko'rinish", "Boshqa ilovalar ustida oyna ko'rsatadi", RiskLevel.SUSPICIOUS
            ),
            "android.permission.READ_PHONE_STATE" to Triple(
                "Telefon holati", "IMEI, telefon raqami va tarmoq ma'lumotlarini o'qiydi", RiskLevel.SUSPICIOUS
            ),
            "android.permission.CALL_PHONE" to Triple(
                "Qo'ng'iroq qilish", "Sizning roziligingisiz qo'ng'iroq qilishi mumkin", RiskLevel.DANGEROUS
            ),
            "android.permission.BLUETOOTH" to Triple(
                "Bluetooth", "Bluetooth qurilmalariga ulanadi", RiskLevel.SAFE
            ),
            "android.permission.NFC" to Triple(
                "NFC", "NFC orqali ma'lumot almashadi", RiskLevel.SUSPICIOUS
            ),
            "android.permission.USE_BIOMETRIC" to Triple(
                "Biometrik autentifikatsiya", "Barmoq izi yoki yuz aniqlashdan foydalanadi", RiskLevel.SAFE
            ),
            "android.permission.VIBRATE" to Triple(
                "Tebranish", "Qurilmani tebrantiradi (bildirishnomalar uchun)", RiskLevel.SAFE
            ),
            "android.permission.WAKE_LOCK" to Triple(
                "Uyqu rejimini bloklash", "Ekran o'chmasligi uchun qurilmani uyg'iq saqlaydi", RiskLevel.SUSPICIOUS
            ),
            "android.permission.GET_ACCOUNTS" to Triple(
                "Akkauntlar ro'yxati", "Qurilmadagi barcha Google va boshqa akkauntlarni ko'radi", RiskLevel.SUSPICIOUS
            ),
            "android.permission.USE_CREDENTIALS" to Triple(
                "Akkaunt ma'lumotlari", "Akkaunt tokenlarini olishi mumkin", RiskLevel.DANGEROUS
            ),
            "android.permission.MANAGE_ACCOUNTS" to Triple(
                "Akkauntlarni boshqarish", "Akkauntlarni qo'shish, o'chirish mumkin", RiskLevel.DANGEROUS
            ),
            "android.permission.KILL_BACKGROUND_PROCESSES" to Triple(
                "Fon jarayonlarini o'ldirish", "Boshqa ilovalarni majburan to'xtatadi", RiskLevel.SUSPICIOUS
            ),
            "android.permission.CHANGE_NETWORK_STATE" to Triple(
                "Tarmoq holatini o'zgartirish", "Wi-Fi, mobil ma'lumotlarni yoqadi/o'chiradi", RiskLevel.SUSPICIOUS
            ),
            "android.permission.CHANGE_WIFI_STATE" to Triple(
                "Wi-Fi holatini o'zgartirish", "Wi-Fi ni yoqadi/o'chiradi, tarmoqlarni boshqaradi", RiskLevel.SUSPICIOUS
            ),
            "android.permission.ACCESS_WIFI_STATE" to Triple(
                "Wi-Fi holati", "Ulanilgan Wi-Fi tarmoq ma'lumotlarini ko'radi", RiskLevel.SAFE
            ),
            "android.permission.BIND_ACCESSIBILITY_SERVICE" to Triple(
                "Maxsus imkoniyatlar xizmati", "Ekrandagi hamma narsani o'qishi va boshqarishi mumkin", RiskLevel.DANGEROUS
            ),
            "android.permission.BIND_DEVICE_ADMIN" to Triple(
                "Qurilma administratori", "Qurilmani masofadan boshqarishi, bloklashi mumkin", RiskLevel.DANGEROUS
            )
        )

        // URL/IP/domain topish uchun regex
        private val URL_REGEX = Regex(
            """https?://[a-zA-Z0-9\-._~:/?#\[\]@!${'$'}&'()*+,;=%]{4,200}""",
            RegexOption.IGNORE_CASE
        )
        private val IP_REGEX = Regex(
            """\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)(?::\d{2,5})?\b"""
        )
        private val DOMAIN_REGEX = Regex(
            """\b([a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+(?:com|net|org|io|app|dev|api|xyz|info|co|ru|uz|tk|ml|ga)\b"""
        )

        // Xavfli string belgilari
        private val DANGER_STRINGS = listOf(
            "su" to "Root buyruq",
            "superuser" to "Root imtiyozi",
            "getRunningServices" to "Xizmatlarni skanerlash",
            "execShell" to "Shell buyruq bajarish",
            "Runtime.exec" to "Tizim buyruqlarini bajarish",
            "/proc/net" to "Tarmoq jarayonlariga kirish",
            "keylogger" to "Klaviatura kuzatuvchi",
            "getPassword" to "Parol olishga urinish",
            "captureScreen" to "Ekran suratini olish",
            "backdoor" to "Maxfiy kirish eshigi",
            "trojan" to "Troyan belgilari",
            "malware" to "Zararli dastur belgisi"
        )
    }

    // ─── Asosiy tahlil funksiyasi ─────────────────────────────────────────

    suspend fun analyze(apkFile: File, onStep: (String) -> Unit): ApkAnalysisResult {

        onStep("APK fayli tekshirilmoqda…")
        val sizeBytes = apkFile.length()

        // 1. PackageManager orqali meta ma'lumot
        onStep("Paket ma'lumotlari o'qilmoqda…")
        val pm = context.packageManager

        @Suppress("DEPRECATION")
        val pkgInfo: PackageInfo? = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageArchiveInfo(
                    apkFile.absolutePath,
                    PackageManager.PackageInfoFlags.of(
                        (PackageManager.GET_PERMISSIONS or
                         PackageManager.GET_META_DATA).toLong()
                    )
                )
            } else {
                pm.getPackageArchiveInfo(
                    apkFile.absolutePath,
                    PackageManager.GET_PERMISSIONS or PackageManager.GET_META_DATA
                )
            }
        } catch (e: Exception) {
            null
        }

        val packageName = pkgInfo?.packageName ?: "aniqlanmadi"
        val versionName = pkgInfo?.versionName ?: "—"
        val versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            pkgInfo?.longVersionCode ?: 0L
        } else {
            @Suppress("DEPRECATION")
            pkgInfo?.versionCode?.toLong() ?: 0L
        }

        // 2. Ruxsatlar tahlili
        onStep("Ruxsatlar tahlil qilinmoqda…")
        val rawPerms = pkgInfo?.requestedPermissions?.toList() ?: emptyList()
        val permissions = rawPerms.map { perm ->
            val db = PERMISSION_DB[perm]
            if (db != null) {
                PermissionInfo(
                    name = perm,
                    shortName = db.first,
                    description = db.second,
                    riskLevel = db.third
                )
            } else {
                val short = perm.substringAfterLast(".")
                PermissionInfo(
                    name = perm,
                    shortName = short,
                    description = "Noma'lum ruxsat: $short",
                    riskLevel = RiskLevel.SUSPICIOUS
                )
            }
        }

        // 3. ZIP ichini skanerlash — URL, IP, xavfli string
        onStep("ZIP tarkibi skanerlanoqda…")
        val networkEndpoints = mutableListOf<NetworkEndpoint>()
        val dangerSignals = mutableListOf<DangerSignal>()
        val foundUrls = mutableSetOf<String>()
        val foundIps = mutableSetOf<String>()
        val foundDomains = mutableSetOf<String>()

        try {
            ZipFile(apkFile).use { zip ->
                val entries = zip.entries().toList()

                for (entry in entries) {
                    if (entry.isDirectory) continue
                    val name = entry.name.lowercase()

                    // faqat matnli/binary fayllarni skan qilamiz (rasmlar emas)
                    val scannable = name.endsWith(".dex") ||
                        name.endsWith(".xml") ||
                        name.endsWith(".json") ||
                        name.endsWith(".properties") ||
                        name.endsWith(".txt") ||
                        name.endsWith(".js") ||
                        name.endsWith(".smali") ||
                        (!name.contains(".") && name.length < 50)

                    if (!scannable && !name.endsWith(".dex") && !name.endsWith(".xml")) continue
                    if (entry.size > 10 * 1024 * 1024) continue // 10MB+ skip

                    try {
                        val bytes = zip.getInputStream(entry).readBytes()
                        val text = String(bytes, Charsets.ISO_8859_1)

                        // URL topish
                        URL_REGEX.findAll(text).forEach { match ->
                            val url = match.value.take(200)
                            if (!url.contains("schemas.android.com") &&
                                !url.contains("www.w3.org") &&
                                !url.contains("xmlns") &&
                                foundUrls.size < 30
                            ) {
                                foundUrls.add(url)
                            }
                        }

                        // IP topish
                        IP_REGEX.findAll(text).forEach { match ->
                            val ip = match.value
                            if (!ip.startsWith("0.") && !ip.startsWith("127.") &&
                                !ip.startsWith("255.") && foundIps.size < 20
                            ) {
                                foundIps.add(ip)
                            }
                        }

                        // Domain topish (DEX va XML da)
                        if (name.endsWith(".dex") || name.endsWith(".xml")) {
                            DOMAIN_REGEX.findAll(text).forEach { match ->
                                val dom = match.value
                                if (foundDomains.size < 20 &&
                                    !dom.contains("android") &&
                                    !dom.contains("google") &&
                                    dom.length > 5
                                ) {
                                    foundDomains.add(dom)
                                }
                            }
                        }

                        // Xavfli string skaneri (faqat DEX)
                        if (name.endsWith(".dex")) {
                            for ((str, label) in DANGER_STRINGS) {
                                if (text.contains(str, ignoreCase = true)) {
                                    dangerSignals.add(
                                        DangerSignal(
                                            title = label,
                                            detail = "\"$str\" belgisi aniqlandi",
                                            source = entry.name
                                        )
                                    )
                                }
                            }
                        }

                    } catch (_: Exception) {}
                }
            }
        } catch (_: Exception) {
            dangerSignals.add(
                DangerSignal(
                    title = "ZIP o'qish xatosi",
                    detail = "APK fayli buzilgan yoki himoyalangan bo'lishi mumkin",
                    source = apkFile.name
                )
            )
        }

        // Network endpointlarni yig'ish
        foundUrls.forEach { networkEndpoints.add(NetworkEndpoint(it, "URL")) }
        foundIps.forEach { networkEndpoints.add(NetworkEndpoint(it, "IP")) }
        foundDomains.forEach { networkEndpoints.add(NetworkEndpoint(it, "Domain")) }

        // 4. Xavf hisoblash
        onStep("Xavf darajasi aniqlanmoqda…")
        val dangerPerms = permissions.filter { it.riskLevel == RiskLevel.DANGEROUS }
        val suspPerms = permissions.filter { it.riskLevel == RiskLevel.SUSPICIOUS }
        val hasNetwork = permissions.any { it.name == "android.permission.INTERNET" }

        val verdict: RiskLevel
        val verdictSummary: String

        when {
            dangerSignals.size >= 2 || dangerPerms.size >= 3 -> {
                verdict = RiskLevel.DANGEROUS
                verdictSummary = buildString {
                    if (dangerSignals.isNotEmpty()) append("${dangerSignals.size} ta xavfli kod belgisi aniqlandi. ")
                    if (dangerPerms.isNotEmpty()) append("${dangerPerms.size} ta xavfli ruxsat so'ralmoqda.")
                }
            }
            dangerPerms.isNotEmpty() || suspPerms.size >= 4 || dangerSignals.isNotEmpty() -> {
                verdict = RiskLevel.SUSPICIOUS
                verdictSummary = buildString {
                    if (dangerPerms.isNotEmpty()) append("${dangerPerms.size} ta xavfli ruxsat. ")
                    if (dangerSignals.isNotEmpty()) append("${dangerSignals.size} ta shubhali belgi. ")
                    if (suspPerms.size >= 4) append("Ko'p miqdorda shubhali ruxsatlar.")
                }
            }
            else -> {
                verdict = RiskLevel.SAFE
                verdictSummary = "Hech qanday xavfli belgi aniqlanmadi. Ruxsatlar oddiy darajada."
            }
        }

        // 5. Ilova vazifasi va imkoniyatlarini xulosa qilish
        onStep("Xulosa tayyorlanmoqda…")
        val (purpose, capabilities) = inferPurposeAndCapabilities(
            packageName, rawPerms, networkEndpoints.isNotEmpty(), hasNetwork
        )

        // minSdk
        val minSdk = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                pkgInfo?.applicationInfo?.minSdkVersion ?: 0
            } else 0
        } catch (_: Exception) { 0 }

        return ApkAnalysisResult(
            apkName = apkFile.name,
            packageName = packageName,
            versionName = versionName,
            versionCode = versionCode,
            minSdkVersion = minSdk,
            targetSdkVersion = pkgInfo?.applicationInfo?.targetSdkVersion ?: 0,
            fileSizeBytes = sizeBytes,
            appPurpose = purpose,
            capabilities = capabilities,
            permissions = permissions,
            networkEndpoints = networkEndpoints,
            dangerSignals = dangerSignals,
            verdict = verdict,
            verdictSummary = verdictSummary
        )
    }

    // ─── Vazifa va imkoniyatlarni aniqlash ───────────────────────────────

    private fun inferPurposeAndCapabilities(
        packageName: String,
        perms: List<String>,
        hasNetwork: Boolean,
        hasInternet: Boolean
    ): Pair<String, List<String>> {

        val caps = mutableListOf<String>()
        val purposes = mutableListOf<String>()

        val hasCam = perms.any { it.contains("CAMERA") }
        val hasMic = perms.any { it.contains("RECORD_AUDIO") }
        val hasLoc = perms.any { it.contains("LOCATION") }
        val hasSms = perms.any { it.contains("SMS") }
        val hasContacts = perms.any { it.contains("CONTACTS") }
        val hasStorage = perms.any { it.contains("STORAGE") || it.contains("MEDIA") }
        val hasPhone = perms.any { it.contains("PHONE_STATE") || it.contains("CALL") }
        val hasBoot = perms.any { it.contains("BOOT_COMPLETED") }
        val hasAdmin = perms.any { it.contains("DEVICE_ADMIN") || it.contains("ACCESSIBILITY") }
        val hasInstall = perms.any { it.contains("INSTALL_PACKAGES") }

        // Paket nomiga qarab taxminiy tur
        val pkgLower = packageName.lowercase()
        when {
            pkgLower.contains("game") || pkgLower.contains("play") -> purposes.add("O'yin ilovasi")
            pkgLower.contains("bank") || pkgLower.contains("pay") || pkgLower.contains("finance") ->
                purposes.add("Bank / to'lov ilovasi")
            pkgLower.contains("vpn") || pkgLower.contains("proxy") -> purposes.add("VPN / proksi ilovasi")
            pkgLower.contains("chat") || pkgLower.contains("messenger") || pkgLower.contains("telegram") ->
                purposes.add("Xabar almashish ilovasi")
            pkgLower.contains("camera") || pkgLower.contains("photo") -> purposes.add("Kamera / foto ilovasi")
            pkgLower.contains("music") || pkgLower.contains("audio") -> purposes.add("Musiqa ilovasi")
            pkgLower.contains("util") || pkgLower.contains("cleaner") || pkgLower.contains("booster") ->
                purposes.add("Tizim yordamchi ilovasi")
            else -> purposes.add("Umumiy Android ilovasi")
        }

        // Imkoniyatlar
        if (hasInternet || hasNetwork) caps.add("Internet orqali serverga ulanadi")
        if (hasCam) caps.add("Kameraga kiradi")
        if (hasMic) caps.add("Mikrofondan foydalanadi")
        if (hasLoc) caps.add("Joylashuvni aniqlaydi")
        if (hasSms) caps.add("SMS xabarlarni boshqaradi")
        if (hasContacts) caps.add("Kontaktlarga kiradi")
        if (hasStorage) caps.add("Fayillarga kiradi (o'qish/yozish)")
        if (hasPhone) caps.add("Telefon qo'ng'iroqlarini boshqaradi")
        if (hasBoot) caps.add("Qurilma yoqilganda avtomatik ishga tushadi")
        if (hasAdmin) caps.add("Maxsus imkoniyatlar orqali qurilmani boshqaradi")
        if (hasInstall) caps.add("Boshqa APK fayllarni o'rnatishi mumkin")
        if (caps.isEmpty()) caps.add("Tarmoqsiz, cheklangan imkoniyatlar bilan ishlaydi")

        return Pair(purposes.joinToString(", "), caps)
    }
}
